/******************************************************
 * Project:         Práctica 2 de Sistemas Operativos II
 * 
 * Program name:    Resultado.h
 * 
 * Author:          Miguel Angel Roldan Mora
 *                  Diego Dorado Galán
 *                  Carlos Rodríguez Gómez-Carreño
 * 
 * Date created:    08/04/2022
 * 
 * Purpose:         Clase resultado, la cual utilizaremos para mostrar de forma adecuada los datos obtenidos del fichero 
 * 
 ******************************************************/

#include <iostream>
#include <queue>
#include "../include/Datos.h" 

class Resultado{
    private:
        int hilo;
        int primera_linea;
        int linea_final;
        std::queue<Datos> queque;
        
    public:
        Resultado(int hilo, int primera_linea, int linea_final);
        int  getHilo(); 
        int  getLinea_Final(); 
        int  getPrimera_linea(); 
        void llenar_cola(Datos cont); 
        void mostrar_resultado(); 
};