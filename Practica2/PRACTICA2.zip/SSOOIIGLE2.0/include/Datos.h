/******************************************************
 * Project:         Práctica 2 de Sistemas Operativos II
 * 
 * Program name:    Datos.h
 * 
 * Author:          Miguel Angel Roldan Mora
 *                  Diego Dorado Galán
 *                  Carlos Rodríguez Gómez-Carreño
 * 
 * Date created:    08/04/2022
 * 
 ******************************************************/

#include <iostream>
#include <queue>

struct Datos{
    int          nline; 
    std::string  anterior; 
    std::string  posterior;
    std::string  palabra; 
};